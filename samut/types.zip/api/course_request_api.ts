import apiClient from "./api_client"
import { APIEndpoints } from "@/constants/apiEndpoints"

// Get pending course requests for the instructor
export const getPendingCourseRequests = async () => {
  try {
    const response = await apiClient.get(APIEndpoints.COURSE_REQUESTS.INSTRUCTOR_PENDING)
    return response.data
  } catch (error) {
    console.error("Error fetching pending course requests:", error)
    // Return empty array instead of throwing to prevent UI crashes
    return []
  }
}

// Approve a course request
export const approveCourseRequest = async (requestId: string) => {
  try {
    const response = await apiClient.put(`${APIEndpoints.COURSE_REQUESTS.BASE}/${requestId}/approve`)
    return response.data
  } catch (error) {
    console.error("Error approving course request:", error)
    throw error
  }
}

// Reject a course request
export const rejectCourseRequest = async (requestId: string) => {
  try {
    const response = await apiClient.put(`${APIEndpoints.COURSE_REQUESTS.BASE}/${requestId}/reject`)
    return response.data
  } catch (error) {
    console.error("Error rejecting course request:", error)
    throw error
  }
}
