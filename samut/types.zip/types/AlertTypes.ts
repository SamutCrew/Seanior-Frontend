// types/AlertTypes.ts
export enum AlertType {
    SUCCESS = "success",
    ERROR = "error",
    WARNING = "warning",
    INFO = "info",
  }
  