import en from './en.json';
import th from './th.json';

export const homeTranslations = { en, th };