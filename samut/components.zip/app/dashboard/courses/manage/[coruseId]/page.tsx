"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import {
  FaStar,
  FaUsers,
  FaArrowLeft,
  FaEdit,
  FaChartLine,
  FaChalkboardTeacher,
  FaBook,
  FaCalendarAlt,
  FaSwimmer,
} from "react-icons/fa"
import { Button } from "@/components/Common/Button"
import { useAppSelector } from "@/app/redux"
import CourseProgressTracker from "@/components/Course/CourseProgressTracker"
import WeeklyLessonUpdate from "@/components/Course/WeeklyLessonUpdate"
import type { Course, CourseProgress } from "@/types/course"
import ProgressTimeline from "@/components/Course/ProgressTimeline"

// Sample course data - in a real app, this would come from an API
const sampleCourse: Course = {
  id: 1,
  title: "Freestyle Mastery",
  focus: "Perfect your freestyle technique with Olympic-level instruction",
  level: "Intermediate",
  duration: "8 weeks",
  schedule: "Mon/Wed 5-6pm",
  instructor: "Michael Phelps",
  instructorId: "1",
  rating: 4.8,
  students: 1,
  maxStudents: 1,
  price: 299,
  courseType: "public-pool",
  location: {
    address: "Aquatic Center, Los Angeles, CA",
  },
  description:
    "This comprehensive course focuses on perfecting your freestyle technique through detailed instruction and practice. You'll learn advanced breathing techniques, efficient arm movements, and proper body positioning to maximize your speed and endurance in the water. Suitable for intermediate swimmers who want to take their freestyle to the next level.",
  curriculum: [
    "Week 1-2: Body positioning and balance",
    "Week 3-4: Arm stroke mechanics and efficiency",
    "Week 5-6: Breathing techniques and timing",
    "Week 7-8: Speed development and endurance training",
  ],
  requirements: [
    "Ability to swim 100m freestyle without stopping",
    "Basic understanding of freestyle technique",
    "Own swimming equipment (goggles, swim cap)",
    "Commitment to attend at least 80% of sessions",
  ],
  image: "/focused-freestyle.png",
  progress: {
    overallCompletion: 65,
    modules: [
      {
        id: 1,
        title: "Body positioning and balance",
        completion: 100,
        topics: [
          { id: 101, title: "Horizontal body position", completed: true },
          { id: 102, title: "Core engagement", completed: true },
          { id: 103, title: "Head position in water", completed: true },
        ],
      },
      {
        id: 2,
        title: "Arm stroke mechanics",
        completion: 75,
        topics: [
          { id: 201, title: "Entry and catch phase", completed: true },
          { id: 202, title: "Pull phase technique", completed: true },
          { id: 203, title: "Recovery phase", completed: true },
          { id: 204, title: "Hand position optimization", completed: false },
        ],
      },
      {
        id: 3,
        title: "Breathing techniques",
        completion: 33,
        topics: [
          { id: 301, title: "Bilateral breathing", completed: true },
          { id: 302, title: "Breath timing", completed: false },
          { id: 303, title: "Breath control exercises", completed: false },
        ],
      },
      {
        id: 4,
        title: "Speed development",
        completion: 0,
        topics: [
          { id: 401, title: "Interval training", completed: false },
          { id: 402, title: "Sprint technique", completed: false },
          { id: 403, title: "Race pace training", completed: false },
        ],
      },
    ],
    lastUpdated: "2023-05-15T14:30:00Z",
    sessionDetails: [
      {
        id: "session-1",
        date: "2023-05-10",
        title: "Body Position Fundamentals",
        description:
          "Focused on horizontal body alignment and core engagement. Students practiced floating exercises and basic streamline position.",
        images: ["/swimming-lesson-body-position.png"],
        moduleId: 1,
        topicId: 101,
      },
    ],
    weeklyUpdates: [
      {
        id: "week-1",
        weekNumber: 1,
        date: "2023-05-10",
        title: "Introduction to Freestyle",
        content:
          "Covered basic body positioning and water comfort. Students practiced floating and basic arm movements.",
        achievements: "All students can now float comfortably on their back and front.",
        challenges: "Some students struggling with keeping their legs up while floating.",
        nextSteps: "Will focus on kicking technique next week.",
        images: ["/placeholder.svg?key=phlyj"],
      },
    ],
  },
}

export default function CourseManagementPage() {
  const params = useParams()
  const router = useRouter()
  const [course, setCourse] = useState<Course | null>(null)
  const [loading, setLoading] = useState(true)
  const isDarkMode = useAppSelector((state) => state.global.isDarkMode)
  const [activeTab, setActiveTab] = useState<"progress" | "weekly" | "students" | "settings">("weekly")
  const [courseInfoVisible, setCourseInfoVisible] = useState(false)

  // Simplified course loading
  useEffect(() => {
    const fetchCourse = async () => {
      try {
        // Simulate API delay for realism
        await new Promise((resolve) => setTimeout(resolve, 600))
        setCourse(sampleCourse)
      } catch (error) {
        console.error("Failed to fetch course data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchCourse()
  }, [])

  const handleBack = () => {
    router.push("/dashboard")
  }

  // Handle progress update
  const handleProgressUpdate = (updatedProgress: CourseProgress) => {
    if (course) {
      setCourse({
        ...course,
        progress: updatedProgress,
      })
      console.log("Progress updated:", updatedProgress)
    }
  }

  // Loading state with improved animation
  if (loading) {
    return (
      <div
        className={`min-h-screen flex flex-col items-center justify-center ${isDarkMode ? "bg-slate-900" : "bg-gray-50"}`}
      >
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
        <p className={`text-sm ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Loading course data...</p>
      </div>
    )
  }

  // Error state
  if (!course) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${isDarkMode ? "bg-slate-900 text-white" : "bg-gray-50 text-gray-800"}`}
      >
        <div className="text-center max-w-md mx-auto px-4">
          <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
          <p className={isDarkMode ? "text-gray-300 mb-6" : "text-gray-600 mb-6"}>
            The course you're looking for doesn't exist or has been removed.
          </p>
          <Button variant="primary" onClick={handleBack}>
            <FaArrowLeft className="mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? "bg-slate-900 text-white" : "bg-gray-50 text-gray-900"}`}>
      {/* Course Header - Redesigned for better UX */}
      <div className={`${isDarkMode ? "bg-slate-800" : "bg-white"} shadow-md transition-colors duration-300`}>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center mb-4">
            <button
              onClick={handleBack}
              className={`mr-4 p-2 rounded-full ${
                isDarkMode ? "hover:bg-slate-700 text-gray-300" : "hover:bg-gray-100 text-gray-600"
              } transition-colors`}
              aria-label="Back to Dashboard"
            >
              <FaArrowLeft />
            </button>
            <h1 className="text-2xl font-bold">Course Management</h1>
          </div>

          {/* Enhanced Course Info Card */}
          <motion.div
            className={`rounded-xl overflow-hidden ${
              isDarkMode ? "bg-slate-700/50" : "bg-white border border-gray-100"
            } shadow-sm transition-colors duration-300`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="flex flex-col md:flex-row">
              {/* Course Image */}
              <div className="md:w-1/4 lg:w-1/5">
                <div className="aspect-video md:aspect-square w-full h-full relative">
                  <Image
                    src={course.image || "/placeholder.svg?height=400&width=400&query=swimming course"}
                    alt={course.title}
                    fill
                    className="object-cover"
                  />
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${
                      isDarkMode ? "from-slate-900/80 to-transparent" : "from-black/50 to-transparent"
                    }`}
                  ></div>
                  <div className="absolute bottom-3 left-3 flex items-center gap-1 text-white">
                    <FaStar className="h-4 w-4 text-amber-400" />
                    <span className="text-sm font-medium">{course.rating.toFixed(1)}</span>
                  </div>
                </div>
              </div>

              {/* Course Details */}
              <div className="p-5 flex-grow">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      course.level === "Beginner"
                        ? isDarkMode
                          ? "bg-green-900/30 text-green-400 border border-green-800/50"
                          : "bg-green-100 text-green-800 border border-green-200"
                        : course.level === "Intermediate"
                          ? isDarkMode
                            ? "bg-blue-900/30 text-blue-400 border border-blue-800/50"
                            : "bg-blue-100 text-blue-800 border border-blue-200"
                          : isDarkMode
                            ? "bg-purple-900/30 text-purple-400 border border-purple-800/50"
                            : "bg-purple-100 text-purple-800 border border-purple-200"
                    }`}
                  >
                    {course.level}
                  </span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      isDarkMode
                        ? "bg-slate-800 text-gray-300 border border-slate-700"
                        : "bg-gray-100 text-gray-700 border border-gray-200"
                    }`}
                  >
                    {course.duration}
                  </span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      isDarkMode
                        ? "bg-slate-800 text-gray-300 border border-slate-700"
                        : "bg-gray-100 text-gray-700 border border-gray-200"
                    }`}
                  >
                    {course.schedule}
                  </span>
                </div>

                <h2 className="text-xl font-bold mb-1">{course.title}</h2>
                <p className={`text-sm mb-3 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>{course.focus}</p>

                <div className="flex flex-wrap gap-4 mt-4">
                  <div className={`flex items-center gap-2 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                    <FaSwimmer className="h-4 w-4" />
                    <span className="text-sm">{course.students} student enrolled</span>
                  </div>
                  <div className={`flex items-center gap-2 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                    <FaCalendarAlt className="h-4 w-4" />
                    <span className="text-sm">
                      Last updated:{" "}
                      {course.progress ? new Date(course.progress.lastUpdated).toLocaleDateString() : "No data"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div
                className="p-5 md:border-l md:flex md:flex-col md:justify-center space-y-3 md:w-1/4 lg:w-1/5 
                border-t md:border-t-0 border-gray-100 dark:border-slate-700"
              >
                <Button
                  variant="outline"
                  className="w-full flex items-center justify-center gap-2"
                  onClick={() => setCourseInfoVisible(!courseInfoVisible)}
                >
                  <FaChalkboardTeacher className="h-4 w-4" />
                  <span>Course Details</span>
                </Button>
                <Button variant="primary" className="w-full flex items-center justify-center gap-2">
                  <FaEdit className="h-4 w-4" />
                  <span>Edit Course</span>
                </Button>
              </div>
            </div>

            {/* Expandable Course Info */}
            <AnimatePresence>
              {courseInfoVisible && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className={`p-5 border-t ${isDarkMode ? "border-slate-700" : "border-gray-100"}`}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                          Course Description
                        </h3>
                        <p className={`text-sm ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                          {course.description}
                        </p>
                      </div>
                      <div>
                        <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                          Curriculum Overview
                        </h3>
                        <ul className={`text-sm space-y-1 ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                          {course.curriculum?.map((item, index) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{item}</span>
                            </li>
                          )) || <li className="italic">No curriculum information available</li>}
                        </ul>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      {/* Tab Navigation - Enhanced for better UX */}
      <div className={`border-b ${isDarkMode ? "border-slate-700" : "border-gray-200"} transition-colors duration-300`}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex overflow-x-auto">
            <TabButton
              active={activeTab === "weekly"}
              onClick={() => setActiveTab("weekly")}
              icon={<FaBook className="h-4 w-4" />}
              label="Weekly Updates"
              isDarkMode={isDarkMode}
            />
            <TabButton
              active={activeTab === "progress"}
              onClick={() => setActiveTab("progress")}
              icon={<FaChartLine className="h-4 w-4" />}
              label="Progress Tracking"
              isDarkMode={isDarkMode}
            />
            <TabButton
              active={activeTab === "students"}
              onClick={() => setActiveTab("students")}
              icon={<FaUsers className="h-4 w-4" />}
              label="Students"
              isDarkMode={isDarkMode}
            />
            <TabButton
              active={activeTab === "settings"}
              onClick={() => setActiveTab("settings")}
              icon={<FaEdit className="h-4 w-4" />}
              label="Course Settings"
              isDarkMode={isDarkMode}
            />
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {activeTab === "weekly" && (
            <motion.div
              key="weekly"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <div className="mb-6">{course.progress && <ProgressTimeline progress={course.progress} />}</div>
              <WeeklyLessonUpdate
                courseId={course.id}
                initialProgress={
                  course.progress || {
                    overallCompletion: 0,
                    modules: [],
                    lastUpdated: new Date().toISOString(),
                    weeklyUpdates: [],
                  }
                }
                onSave={handleProgressUpdate}
              />
            </motion.div>
          )}

          {activeTab === "progress" && (
            <motion.div
              key="progress"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <CourseProgressTracker
                courseId={course.id}
                initialProgress={
                  course.progress || {
                    overallCompletion: 0,
                    modules: [],
                    lastUpdated: new Date().toISOString(),
                    weeklyUpdates: [],
                  }
                }
                onSave={handleProgressUpdate}
              />
            </motion.div>
          )}

          {activeTab === "students" && (
            <motion.div
              key="students"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <motion.div
                className={`rounded-xl p-6 ${isDarkMode ? "bg-slate-800" : "bg-white"} shadow-sm transition-colors duration-300`}
              >
                <h2 className={`text-xl font-bold mb-6 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Student Management
                </h2>
                <p className={`${isDarkMode ? "text-gray-300" : "text-gray-600"} mb-4`}>
                  Currently {course.students} student enrolled in this course.
                </p>

                <div
                  className={`p-8 text-center rounded-lg border-2 border-dashed ${
                    isDarkMode ? "border-slate-700 text-gray-400" : "border-gray-200 text-gray-500"
                  } transition-colors duration-300`}
                >
                  Student management interface will be implemented here
                </div>
              </motion.div>
            </motion.div>
          )}

          {activeTab === "settings" && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <motion.div
                className={`rounded-xl p-6 ${isDarkMode ? "bg-slate-800" : "bg-white"} shadow-sm transition-colors duration-300`}
              >
                <h2 className={`text-xl font-bold mb-6 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                  Course Settings
                </h2>

                <div
                  className={`p-8 text-center rounded-lg border-2 border-dashed ${
                    isDarkMode ? "border-slate-700 text-gray-400" : "border-gray-200 text-gray-500"
                  } transition-colors duration-300`}
                >
                  Course settings interface will be implemented here
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

// Tab Button Component for cleaner code
interface TabButtonProps {
  active: boolean
  onClick: () => void
  icon: React.ReactNode
  label: string
  isDarkMode: boolean
}

function TabButton({ active, onClick, icon, label, isDarkMode }: TabButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`py-4 px-6 font-medium border-b-2 transition-colors whitespace-nowrap ${
        active
          ? isDarkMode
            ? "border-cyan-500 text-cyan-400"
            : "border-blue-600 text-blue-600"
          : isDarkMode
            ? "border-transparent text-gray-400 hover:text-gray-300"
            : "border-transparent text-gray-500 hover:text-gray-700"
      }`}
    >
      <span className="inline-block mr-2">{icon}</span> {label}
    </button>
  )
}
