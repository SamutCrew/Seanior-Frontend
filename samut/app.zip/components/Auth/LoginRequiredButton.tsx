"use client"

import React, { type MouseEvent } from "react"
import { useAuth } from "@/context/AuthContext"
import AuthWarning from "./AuthWarning"

interface LoginRequiredButtonProps {
  children: React.ReactNode
  onClick?: (event: MouseEvent<HTMLButtonElement>) => void
  className?: string
  warningMessage?: string
}

const LoginRequiredButton: React.FC<LoginRequiredButtonProps> = ({
  children,
  onClick,
  className,
  warningMessage = "You must be logged in to perform this action",
}) => {
  const { isAuthenticated } = useAuth()
  const [showAuthWarning, setShowAuthWarning] = React.useState(false)

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    if (!isAuthenticated) {
      event.preventDefault()
      setShowAuthWarning(true)
    } else {
      onClick?.(event)
    }
  }

  return (
    <>
      <button onClick={handleClick} className={className}>
        {children}
      </button>
      {showAuthWarning && <AuthWarning message={warningMessage} onClose={() => setShowAuthWarning(false)} />}
    </>
  )
}

export default LoginRequiredButton
