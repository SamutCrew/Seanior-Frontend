"use client"
import LoadingPage from "@/components/Common/LoadingPage"

export default function Loading() {
  return <LoadingPage />
}
